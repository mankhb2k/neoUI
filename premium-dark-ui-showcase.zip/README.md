# Obsidian — Premium Dark UI Showcase

A React + TypeScript + CSS Modules component showcase inspired by premium dark SaaS interfaces with subtle glass surfaces.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

## Included sections

- Buttons and icon buttons
- Surface, glass, metric, profile and pricing cards
- Text fields, select, checkbox, switch and range
- Tabs, breadcrumbs and dropdown navigation
- Dialog, popover and context-menu examples
- Activity table, progress, badges and avatar stack
- Alerts, toast notifications and accordion
- Color tokens, surface depth and motion principles

## Stack

- React 18 + TypeScript
- Vite
- CSS Modules
- lucide-react icons

## Reuse notes

Components are demonstrated in `src/App.tsx` and styles are in `src/App.module.css`.
For a production registry, extract each component into its own folder and define a stable
component schema for structure, style tokens, behavior and animation. Avoid treating
computed CSS as the canonical data model if you plan to export to another UI format.
